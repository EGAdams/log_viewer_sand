/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable functional/prefer-readonly-type */
/*
 *  interface IApiArgs
 */
type IApiArgs = {
    thisObject: any;
    trigger: string;
    query: string;
    data: any;
};

export default IApiArgs;
