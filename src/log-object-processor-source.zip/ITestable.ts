/* eslint-disable functional/no-method-signature */
/* eslint-disable functional/prefer-type-literal */
/*
 *  interface ITestable
 */
interface ITestable {
    testMe(): void;
}

export default ITestable;
